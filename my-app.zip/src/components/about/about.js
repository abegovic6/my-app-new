import React from 'react'
import './about.css'

export default function About(){
    return(
        <div className="content">
            <p>about our react academy</p>
        </div>
    )
}
