import React from 'react'
import './contact'

export default function Home(){
    return(
        <div className="content">
            <p>contact codecta</p>
        </div>
    )
}
